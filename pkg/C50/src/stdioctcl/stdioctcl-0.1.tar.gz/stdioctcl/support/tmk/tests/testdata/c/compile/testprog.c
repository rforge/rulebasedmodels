
int main (int argc ,char * argv[]) {
	int a = 1;
	return 0;
}
